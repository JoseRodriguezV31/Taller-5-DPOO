package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.*;

public class ProductoAjustadoTest {
    private ProductoMenu hamburguesa;
    private ProductoAjustado hamburguesaAjustada;
    private Ingrediente queso;
    private Ingrediente tomate;

    @BeforeEach
    void setUp() {
        hamburguesa = new ProductoMenu("Hamburguesa clásica", 15000);
        hamburguesaAjustada = new ProductoAjustado(hamburguesa);
        queso = new Ingrediente("Queso", 2000);
        tomate = new Ingrediente("Tomate", 1000);
    }

    @Test
    void testConstructor() {
        assertEquals("Hamburguesa clásica", hamburguesaAjustada.getNombre());
        assertEquals(15000, hamburguesaAjustada.getPrecio());
    }

    @Test
    void testAgregarIngrediente() {
        hamburguesaAjustada.agregarIngrediente(queso);
        assertEquals(17000, hamburguesaAjustada.getPrecio()); // 15000 + 2000
    }

    @Test
    void testEliminarIngrediente() {
        hamburguesaAjustada.eliminarIngrediente(tomate);
        assertEquals(15000, hamburguesaAjustada.getPrecio()); // Eliminar no afecta el precio
    }

    @Test
    void testGenerarFactura() {
        hamburguesaAjustada.agregarIngrediente(queso);
        hamburguesaAjustada.eliminarIngrediente(tomate);
        String factura = hamburguesaAjustada.generarTextoFactura();
        assertTrue(factura.contains("+Queso                2000"));
        assertTrue(factura.contains("-Tomate"));
        assertTrue(factura.contains("17000"));
    }
}