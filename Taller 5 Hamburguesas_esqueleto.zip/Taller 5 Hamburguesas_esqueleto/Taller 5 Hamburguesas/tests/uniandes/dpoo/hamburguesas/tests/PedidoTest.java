package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.*;

public class PedidoTest {
    private Pedido pedido;
    private ProductoMenu hamburguesa;
    private ProductoMenu papas;
    private Combo comboEspecial;

    @BeforeEach
    void setUp() {
        Pedido.resetearNumeroPedidos(); // Resetear contador estático
        
        hamburguesa = new ProductoMenu("Corral", 14000);
        papas = new ProductoMenu("Papas medianas", 5500);
        
        ArrayList<ProductoMenu> itemsCombo = new ArrayList<>();
        itemsCombo.add(hamburguesa);
        itemsCombo.add(papas);
        comboEspecial = new Combo("Combo Especial", 0.9, itemsCombo);
        
        pedido = new Pedido("Juan Pérez", "Calle 123 #45-67");
    }

    // --- Pruebas del Constructor ---
    @Test
    void testConstructor() {
        assertEquals(0, pedido.getIdPedido());
        assertEquals("Juan Pérez", pedido.getNombreCliente());
        assertEquals("Calle 123 #45-67", pedido.getDireccionCliente());
        assertTrue(pedido.getProductos().isEmpty());
    }

    // --- Pruebas de incremento de ID ---
    @Test
    void testIncrementoIdPedido() {
        new Pedido("Cliente 1", "Dir 1");
        Pedido segundoPedido = new Pedido("Cliente 2", "Dir 2");
        assertEquals(2, segundoPedido.getIdPedido());
    }

    // --- Pruebas de agregarProducto() ---
    @Test
    void testAgregarProductoIndividual() {
        pedido.agregarProducto(hamburguesa);
        assertEquals(1, pedido.getProductos().size());
        assertEquals(14000, pedido.getPrecioNetoPedido());
    }

    @Test
    void testAgregarMultiplesProductos() {
        pedido.agregarProducto(hamburguesa);
        pedido.agregarProducto(papas);
        pedido.agregarProducto(comboEspecial);
        assertEquals(3, pedido.getProductos().size());
    }

    // --- Pruebas de cálculo de precios ---
    @Test
    void testPrecioNetoPedidoVacio() {
        assertEquals(0, pedido.getPrecioNetoPedido());
    }

    @Test
    void testPrecioNetoConProductos() {
        pedido.agregarProducto(hamburguesa);
        pedido.agregarProducto(papas);
        assertEquals(19500, pedido.getPrecioNetoPedido()); // 14000 + 5500
    }

    @Test
    void testPrecioIVAPedido() {
        pedido.agregarProducto(hamburguesa);
        assertEquals(2660, pedido.getPrecioIVAPedido()); // 14000 * 0.19 = 2660
    }

    @Test
    void testPrecioTotalPedido() {
        pedido.agregarProducto(hamburguesa);
        pedido.agregarProducto(comboEspecial);
        int neto = 14000 + (int)((14000 + 5500) * 0.9); // 14000 + 17550 = 31550
        int iva = (int) Math.round(neto * 0.19); // 5994 (con redondeo)
        assertEquals(neto + iva, pedido.getPrecioTotalPedido());
    }

    // --- Pruebas de generarTextoFactura() ---
    @Test
    void testGenerarTextoFacturaVacio() {
        String expected = "Cliente: Juan Pérez\n" +
                        "Dirección: Calle 123 #45-67\n" +
                        "----------------\n" +
                        "----------------\n" +
                        "Precio Neto:  0\n" +
                        "IVA:          0\n" +
                        "Precio Total: 0\n";
        assertEquals(expected, pedido.generarTextoFactura());
    }

    @Test
    void testGenerarTextoFacturaConProductos() {
        pedido.agregarProducto(hamburguesa);
        pedido.agregarProducto(comboEspecial);
        
        String expected = "Cliente: Juan Pérez\n" +
                "Dirección: Calle 123 #45-67\n" +
                "----------------\n" +
                "Corral\n" +
                "            14000\n" +
                "Combo Combo Especial\n" +
                " Descuento: 0.9\n" +
                "            17550\n" +
                "----------------\n" +
                "Precio Neto:  31550\n" +
                "IVA:          5995\n" +
                "Precio Total: 37545\n";
        assertEquals(expected, pedido.generarTextoFactura());

    }

    // --- Pruebas de guardarFactura() ---
    @Test
    void testGuardarFactura() throws Exception {
        pedido.agregarProducto(hamburguesa);
        File tempFile = File.createTempFile("factura", ".txt");
        
        try {
            pedido.guardarFactura(tempFile);
            String contenido = Files.readString(Path.of(tempFile.getAbsolutePath()));
            assertTrue(contenido.contains("Corral"));
            assertTrue(contenido.contains("Precio Total: 16660")); // 14000 + IVA
        } finally {
            tempFile.delete();
        }
    }

    @Test
    void testGuardarFacturaError() {
        File archivoInvalido = new File("/ruta/inexistente/factura.txt");
        assertThrows(FileNotFoundException.class, () -> {
            pedido.guardarFactura(archivoInvalido);
        });
    }

    // --- Pruebas de getters adicionales ---
    @Test
    void testGetDireccionCliente() {
        assertEquals("Calle 123 #45-67", pedido.getDireccionCliente());
    }

    @Test
    void testSetDireccionCliente() {
        pedido.setDireccionCliente("Nueva Dirección 456");
        assertEquals("Nueva Dirección 456", pedido.getDireccionCliente());
    }
}