package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.*;

public class ComboTest {
    private ProductoMenu hamburguesa;
    private ProductoMenu papas;
    private ProductoMenu gaseosa;
    private ArrayList<ProductoMenu> itemsCombo;
    private Combo comboBasico;

    @BeforeEach
    void setUp() {
        hamburguesa = new ProductoMenu("Corral", 14000);
        papas = new ProductoMenu("Papas medianas", 5500);
        gaseosa = new ProductoMenu("Gaseosa", 5000);
        
        itemsCombo = new ArrayList<>();
        itemsCombo.add(hamburguesa);
        itemsCombo.add(papas);
        itemsCombo.add(gaseosa);
        
        comboBasico = new Combo("Combo Corral", 0.9, itemsCombo); // 10% descuento
    }

    // --- Pruebas del Constructor ---
    @Test
    void testConstructor() {
        assertEquals("Combo Corral", comboBasico.getNombre());
        assertEquals(0.9, comboBasico.getDescuento(), 0.001); // Tolerancia para double
        assertEquals(3, comboBasico.getItems().size());
    }

    // --- Pruebas de getPrecio() ---
    @Test
    void testGetPrecioConDescuento() {
        // Precio base: 14000 + 5500 + 5000 = 24500
        // Con 10% descuento: 24500 * 0.9 = 22050
        assertEquals(22050, comboBasico.getPrecio());
    }

    @Test
    void testGetPrecioSinDescuento() {
        Combo comboSinDescuento = new Combo("Sin descuento", 1.0, itemsCombo);
        assertEquals(24500, comboSinDescuento.getPrecio()); // 24500 * 1.0
    }

    @Test
    void testGetPrecioComboVacio() {
        Combo comboVacio = new Combo("Vacio", 0.8, new ArrayList<>());
        assertEquals(0, comboVacio.getPrecio()); // 0 items
    }

    // --- Pruebas de generarTextoFactura() ---
    @Test
    void testGenerarTextoFactura() {
        String expected = "Combo Combo Corral\n" +
                         " Descuento: 0.9\n" +
                         "            22050\n";
        assertEquals(expected, comboBasico.generarTextoFactura());
    }

    @Test
    void testGenerarTextoFacturaSinDescuento() {
        Combo comboSinDescuento = new Combo("Promo", 1.0, itemsCombo);
        String expected = "Combo Promo\n" +
                         " Descuento: 1.0\n" +
                         "            24500\n";
        assertEquals(expected, comboSinDescuento.generarTextoFactura());
    }

    // --- Casos Límite ---
    @Test
    void testDescuentoCero() {
        Combo comboCarisimo = new Combo("Caro", 0.0, itemsCombo);
        assertEquals(0, comboCarisimo.getPrecio()); // 24500 * 0.0
    }

    @Test
    void testDescuentoNegativo() {
        Combo comboRaro = new Combo("Raro", -0.1, itemsCombo);
        assertEquals(-2450, comboRaro.getPrecio()); // 24500 * -0.1 (¿Es válido?)
    }
}