package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;


import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.excepciones.*;
import uniandes.dpoo.hamburguesas.mundo.*;

public class RestauranteTest {
    private Restaurante restaurante;
    private File archivoIngredientes;
    private File archivoMenu;
    private File archivoCombos;

    @BeforeEach
    void setUp() throws IOException {
        restaurante = new Restaurante();
        
        // Crear archivos temporales para pruebas
        archivoIngredientes = crearArchivoTemporal("ingredientes.txt", "lechuga;1000\ntomate;1000");
        archivoMenu = crearArchivoTemporal("menu.txt", "corral;14000\ncorral queso;16000");
        archivoCombos = crearArchivoTemporal("combos.txt", "combo corral;10%;corral;papas medianas");
        
        // Crear carpeta de facturas si no existe
        Files.createDirectories(Path.of(Restaurante.getCarpetaFacturas()));
    }

    @AfterEach
    void tearDown() throws IOException {
        // Limpiar archivos temporales
        archivoIngredientes.delete();
        archivoMenu.delete();
        archivoCombos.delete();
        
        // Limpiar facturas generadas
        Files.walk(Path.of(Restaurante.getCarpetaFacturas()))
             .filter(Files::isRegularFile)
             .forEach(path -> {
                 try { Files.delete(path); } 
                 catch (IOException e) { e.printStackTrace(); }
             });
    }

    private File crearArchivoTemporal(String nombre, String contenido) throws IOException {
        File tempFile = File.createTempFile(nombre.replace(".", ""), ".txt");
        Files.writeString(tempFile.toPath(), contenido);
        return tempFile;
    }

    // --- Pruebas de Constructor ---
    @Test
    void testConstructor() {
        assertTrue(restaurante.getPedidos().isEmpty());
        assertTrue(restaurante.getIngredientes().isEmpty());
        assertTrue(restaurante.getMenuBase().isEmpty());
        assertTrue(restaurante.getMenuCombos().isEmpty());
        assertNull(restaurante.getPedidoEnCurso());
    }

    // --- Pruebas de Carga de Información ---
    @Test
    void testCargarInformacionRestaurante() throws Exception {
        restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);
        
        assertEquals(2, restaurante.getIngredientes().size());
        assertEquals(2, restaurante.getMenuBase().size());
        assertEquals(1, restaurante.getMenuCombos().size());
        
        assertTrue(restaurante.getIngredientes().stream()
            .anyMatch(i -> i.getNombre().equals("lechuga") && i.getCostoAdicional() == 1000));
        
        assertTrue(restaurante.getMenuCombos().get(0).getNombre().contains("combo corral"));
    }

    @Test
    void testCargarIngredienteRepetido() throws IOException {
        File tempFile = crearArchivoTemporal("ing_repetidos.txt", "lechuga;1000\nlechuga;2000");
        
        assertThrows(IngredienteRepetidoException.class, () -> {
            restaurante.cargarInformacionRestaurante(tempFile, archivoMenu, archivoCombos);
        });
    }

    // --- Pruebas de Gestión de Pedidos ---
    @Test
    void testIniciarPedido() throws Exception {
        restaurante.iniciarPedido("Cliente", "Dirección");
        assertNotNull(restaurante.getPedidoEnCurso());
        assertEquals("Cliente", restaurante.getPedidoEnCurso().getNombreCliente());
    }

    @Test
    void testIniciarPedidoConPedidoExistente() throws Exception {
        restaurante.iniciarPedido("Cliente1", "Dirección1");
        assertThrows(YaHayUnPedidoEnCursoException.class, () -> {
            restaurante.iniciarPedido("Cliente2", "Dirección2");
        });
    }

    @Test
    void testCerrarPedidoSinPedido() {
        assertThrows(NoHayPedidoEnCursoException.class, () -> {
            restaurante.cerrarYGuardarPedido();
        });
    }

    @Test
    void testFlujoCompletoPedido() throws Exception {
        // 1. Cargar información
        restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);
        
        // 2. Iniciar pedido
        restaurante.iniciarPedido("Ana", "Calle 123");
        Pedido pedido = restaurante.getPedidoEnCurso();
        assertNotNull(pedido);
        
        // 3. Agregar productos
        pedido.agregarProducto(restaurante.getMenuBase().get(0));
        assertEquals(1, pedido.getProductos().size());
        
        // 4. Cerrar pedido
        restaurante.cerrarYGuardarPedido();
        assertNull(restaurante.getPedidoEnCurso());
        assertEquals(1, restaurante.getPedidos().size());
        
        // 5. Verificar factura
        File factura = new File(Restaurante.getCarpetaFacturas() + 
                              Restaurante.PREFIJO_FACTURAS + pedido.getIdPedido() + ".txt");
        assertTrue(factura.exists());
        assertTrue(factura.length() > 0);
    }

    // --- Pruebas de Archivos ---
    @Test
    void testGuardarFacturaEnDirectorioInexistente() throws Exception {
        // Eliminar directorio de facturas si existe
        Files.deleteIfExists(Path.of(Restaurante.getCarpetaFacturas()));
        
        restaurante.iniciarPedido("Test", "Dirección");
        assertDoesNotThrow(() -> restaurante.cerrarYGuardarPedido());
        
        // Verificar que se creó el directorio
        assertTrue(Files.exists(Path.of(Restaurante.getCarpetaFacturas())));
    }
}