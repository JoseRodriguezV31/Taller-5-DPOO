package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class ProductoMenuTest {
    private ProductoMenu productoBasico;
    private ProductoMenu productoSinPrecio;

    @BeforeEach
    void setUp() {
        productoBasico = new ProductoMenu("corral", 14000);
        productoSinPrecio = new ProductoMenu("agua cristal", 0);
    }

    // --- Pruebas para el Constructor ---
    @Test
    void testConstructorNombreValido() {
        assertEquals("corral", productoBasico.getNombre(), "El nombre no se asignó correctamente");
    }

    @Test
    void testConstructorPrecioValido() {
        assertEquals(14000, productoBasico.getPrecio(), "El precio base no se asignó correctamente");
    }

    @Test
    void testConstructorPrecioCero() {
        assertEquals(0, productoSinPrecio.getPrecio(), "El precio base cero debería ser aceptado");
    }

    // --- Pruebas para getNombre() ---
    @Test
    void testGetNombre() {
        assertEquals("corral", productoBasico.getNombre(), "El nombre retornado no coincide");
    }

    // --- Pruebas para getPrecio() ---
    @Test
    void testGetPrecio() {
        assertEquals(14000, productoBasico.getPrecio(), "El precio retornado no coincide");
    }

    // --- Pruebas para generarTextoFactura() ---
    @Test
    void testGenerarTextoFacturaFormato() {
        String facturaEsperada = "corral\n            14000\n";
        assertEquals(facturaEsperada, productoBasico.generarTextoFactura(), 
            "El formato de la factura no es correcto");
    }

    @Test
    void testGenerarTextoFacturaPrecioCero() {
        String facturaEsperada = "agua cristal\n            0\n";
        assertEquals(facturaEsperada, productoSinPrecio.generarTextoFactura(),
            "La factura con precio cero no se generó correctamente");
    }
    @Test
    void testConstructorPrecioNegativo() {
        assertThrows(IllegalArgumentException.class, () -> {
            new ProductoMenu("producto inválido", -1000);
        }, "Debería lanzar excepción con precio negativo");
    }
}